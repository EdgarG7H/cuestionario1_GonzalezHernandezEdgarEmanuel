# Cargar las librerías necesarias
library(dplyr)
library(readr)

# Cargar el archivo CSV
dataset <- read_csv("Duplicados.csv")

summary(dataset)

dataset$Precio <- ifelse(is.na(dataset$Precio), mean(dataset$Precio, na.rm = TRUE), dataset$Precio)

dataset <- dataset %>% distinct()

# Convertir nombres de productos a minúsculas y eliminar espacios
dataset$Producto <- tolower(trimws(dataset$Producto))







