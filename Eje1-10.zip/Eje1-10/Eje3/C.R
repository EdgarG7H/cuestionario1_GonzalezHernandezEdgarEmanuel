# Cargar librerías necesarias
library(dplyr)

# 1. Cargar y explorar los datasets
clientes <- data.frame(cliente_id = c(1, 2, 3, 4, 5),
                       edad = c(25, 30, 22, 40, 35),
                       ingreso_mensual = c(50000, 60000, 45000, 75000, 80000),
                       genero = c("M", "F", "M", "F", "M"),
                       satisfaccion = c(8, 7, 9, 6, 10),
                       estado_civil = c("Soltero", "Casado", "Soltero", "Divorciado", "Casado"))

compras <- data.frame(compra_id = c(1, 2, 3, 4, 5),
                      cliente_id = c(1, 2, 3, 4, 5),
                      monto = c(200, 150, 300, 400, 250),
                      fecha = as.Date(c("2025-01-01", "2025-01-02", "2025-01-03", "2025-01-04", "2025-01-05")))

# 2. Unir los datasets
datos_unidos <- merge(clientes, compras, by = "cliente_id", all = TRUE)

# 3. Verificar claves duplicadas o valores faltantes
duplicados <- datos_unidos[duplicated(datos_unidos$cliente_id) | duplicated(datos_unidos$cliente_id, fromLast = TRUE), ]
valores_faltantes <- sum(is.na(datos_unidos))

# 4. Consulta de resumen para verificar la integración
resumen <- datos_unidos %>%
  group_by(cliente_id) %>%
  summarise(total_compras = n(), total_gastado = sum(monto, na.rm = TRUE))

# Mostrar resultados
print("Duplicados:")
print(duplicados)
print(paste("Valores faltantes:", valores_faltantes))
print("Resumen de compras:")
print(resumen)
