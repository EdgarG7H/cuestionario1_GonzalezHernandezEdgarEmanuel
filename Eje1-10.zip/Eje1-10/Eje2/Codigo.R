# Crear el dataset
dataset <- data.frame(
  ID = 1:10,
  Fecha = as.Date(c("2025-03-01", "2025-03-02", "2025-03-03", "2025-03-04", "2025-03-05",
                    "2025-03-06", "2025-03-07", "2025-03-08", "2025-03-09", "2025-03-10")),
  Categoria = c("Publicación", "Historia", "Publicación", "Historia", "Publicación",
                "Historia", "Publicación", "Historia", "Publicación", "Historia"),
  Interacciones = c(150, 200, 300, 250, 400, 100, 500, 350, 450, 600),
  Seguidores = c(1000, 1500, 2000, 1200, 1800, 900, 2500, 1600, 2200, 3000),
  Satisfacción = c(8, 7, 9, 6, 10, 5, 9, 8, 7, 10)
)


# Mostrar el dataset
print(dataset)

# Convertir variables categóricas a factores
dataset$Categoria <- as.factor(dataset$Categoria)

# Normalizar columnas numéricas (ejemplo: Interacciones)
dataset$Interacciones <- scale(dataset$Interacciones)

dataset$Ratio_Interaccion <- dataset$Interacciones / dataset$Seguidores

dataset$Fecha <- as.Date(dataset$Fecha, format="%Y-%m-%d")




# 1. Convertir variables categóricas en factores
dataset$Categoria <- factor(dataset$Categoria)

# 2. Normalizar valores numéricos (Interacciones y Seguidores)
dataset$Interacciones <- (dataset$Interacciones - min(dataset$Interacciones)) / (max(dataset$Interacciones) - min(dataset$Interacciones))
dataset$Seguidores <- (dataset$Seguidores - min(dataset$Seguidores)) / (max(dataset$Seguidores) - min(dataset$Seguidores))

# 3. Crear nuevas variables derivadas
dataset$Joven <- ifelse(dataset$Satisfacción >= 8, 1, 0)  # Ejemplo: Joven si la satisfacción es alta

# 4. Convertir fechas en formato adecuado (ya están en formato Date, pero si necesitas otro formato)
# dataset$Fecha <- as.Date(dataset$Fecha, format="%Y-%m-%d") # Este paso es redundante

# Mostrar el dataset transformado
print(dataset)
