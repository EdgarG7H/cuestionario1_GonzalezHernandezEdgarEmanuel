# Cargar las librerías necesarias
library(ggplot2)
library(dplyr)

# Supongamos que 'datos' es tu dataframe y 'produccion' es la columna de interés
# Generar un conjunto de datos de ejemplo
set.seed(123)
datos <- data.frame(produccion = c(rnorm(95, mean = 50000, sd = 10000), 
                                   rnorm(5, mean = 100000, sd = 5000)))  # Añadiendo outliers

# 1. Visualizar los datos con un diagrama de caja
ggplot(datos, aes(x = "", y = produccion)) +
  geom_boxplot() +
  labs(title = "Diagrama de Caja de Producción", y = "Producción")

# 2. Determinar outliers utilizando el rango intercuartil (IQR)
Q1 <- quantile(datos$produccion, 0.25)
Q3 <- quantile(datos$produccion, 0.75)
IQR <- Q3 - Q1

# Definir límites para detectar outliers
limite_inferior <- Q1 - 1.5 * IQR
limite_superior <- Q3 + 1.5 * IQR

# Identificar outliers
outliers <- datos$produccion[datos$produccion < limite_inferior | datos$produccion > limite_superior]

# 3. Aplicar estrategias para manejarlos

# a) Eliminación
datos_sin_outliers <- datos %>%
  filter(produccion >= limite_inferior & produccion <= limite_superior)

# b) Transformación
datos$produccion_transformada <- log(datos$produccion)

# c) Imputación
mediana <- median(datos$produccion, na.rm = TRUE)
datos$produccion_imputada <- ifelse(datos$produccion < limite_inferior | datos$produccion > limite_superior, 
                                    mediana, 
                                    datos$produccion)

# 4. Analizar el impacto de cada estrategia en el dataset
# Estadísticas descriptivas antes
cat("Estadísticas descriptivas antes:\n")
print(summary(datos$produccion))

# Estadísticas descriptivas después de la eliminación
cat("\nEstadísticas descriptivas después de la eliminación:\n")
print(summary(datos_sin_outliers$produccion))

# Estadísticas descriptivas después de la transformación
cat("\nEstadísticas descriptivas después de la transformación:\n")
print(summary(datos$produccion_transformada))

# Estadísticas descriptivas después de la imputación
cat("\nEstadísticas descriptivas después de la imputación:\n")
print(summary(datos$produccion_imputada))
