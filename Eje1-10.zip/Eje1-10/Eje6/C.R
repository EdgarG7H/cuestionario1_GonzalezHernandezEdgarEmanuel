# Cargar librerías necesarias
library(dplyr)
library(tidyr)
library(zoo)  # Para interpolación

# 1. Generar datos simulados y guardar como CSV
set.seed(123)  # Para reproducibilidad
n <- 100  # Número de pacientes
ID <- 1:n
Edad <- sample(18:65, n, replace = TRUE)
Presion_Arterial <- sample(c(NA, rnorm(n, mean = 120, sd = 15)), n, replace = TRUE)  # Incluye algunos NA
Nivel_Glucosa <- sample(c(NA, rnorm(n, mean = 100, sd = 20)), n, replace = TRUE)  # Incluye algunos NA
Genero <- sample(c("M", "F"), n, replace = TRUE)
Satisfaccion <- sample(1:10, n, replace = TRUE)
Compras_Anuales <- sample(1:50, n, replace = TRUE)
Estado_Civil <- sample(c("Soltero", "Casado", "Divorciado"), n, replace = TRUE)

# Crear el dataframe
datos_pacientes <- data.frame(ID, Edad, Presion_Arterial, Nivel_Glucosa, Genero, Satisfaccion, Compras_Anuales, Estado_Civil)

# Guardar el dataframe como un archivo CSV
write.csv(datos_pacientes, "datos_pacientes.csv", row.names = FALSE)

# 2. Cargar el dataset en R usando read.csv()
dataset <- read.csv("datos_pacientes.csv")

# 3. Identificar los valores faltantes con is.na() y summary()
print("Valores faltantes en el dataset:")
print(colSums(is.na(dataset)))

print("Resumen del dataset:")
summary(dataset)

# 4. Aplicar distintas estrategias para manejarlos

# Estrategia 1: Eliminación de filas con na.omit()
dataset_eliminado <- na.omit(dataset)

# Estrategia 2: Imputación con la media (para columnas numéricas)
dataset_imputacion_media <- dataset %>%
  mutate(Presion_Arterial = replace_na(Presion_Arterial, mean(Presion_Arterial, na.rm = TRUE)),
         Nivel_Glucosa = replace_na(Nivel_Glucosa, mean(Nivel_Glucosa, na.rm = TRUE)))

# Estrategia 3: Interpolación (usando zoo)
dataset_interpolado <- dataset %>%
  mutate(Presion_Arterial = na.approx(Presion_Arterial, na.rm = FALSE),
         Nivel_Glucosa = na.approx(Nivel_Glucosa, na.rm = FALSE))

# 5. Comparar los efectos de cada estrategia en el dataset final
cat("Tamaño del dataset original:", nrow(dataset), "\n")
cat("Tamaño del dataset después de eliminar filas:", nrow(dataset_eliminado), "\n")
cat("Tamaño del dataset después de imputación con media:", nrow(dataset_imputacion_media), "\n")
cat("Tamaño del dataset después de interpolación:", nrow(dataset_interpolado), "\n")

# Resumen de los datasets tratados
cat("\nResumen del dataset después de eliminación:\n")
summary(dataset_eliminado)

cat("\nResumen del dataset después de imputación con media:\n")
summary(dataset_imputacion_media)

cat("\nResumen del dataset después de interpolación:\n")
summary(dataset_interpolado)
