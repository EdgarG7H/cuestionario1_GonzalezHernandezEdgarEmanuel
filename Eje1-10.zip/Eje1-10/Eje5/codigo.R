# Cargar librerías necesarias
library(dplyr)
library(caret)  # Para el modelo de machine learning

# Crear un dataset de ejemplo
set.seed(123)  # Para reproducibilidad
dataset <- data.frame(
  ID = 1:10,
  Genero = sample(c("Masculino", "Femenino"), 10, replace = TRUE),
  Estado_Civil = sample(c("Soltero", "Casado", "Divorciado"), 10, replace = TRUE),
  Satisfacción = sample(1:10, 10, replace = TRUE)
)

# 1. Convertir variables cualitativas en numéricas
# Usaremos factor() para convertir a numérico
dataset$Genero <- as.factor(dataset$Genero)
dataset$Estado_Civil <- as.factor(dataset$Estado_Civil)

# 2. Aplicar codificación
# One-hot encoding
dataset_one_hot <- dummyVars(~ ., data = dataset)
dataset_encoded <- predict(dataset_one_hot, newdata = dataset) %>% as.data.frame()

# Label encoding (usando as.numeric)
dataset$Genero_Label <- as.numeric(dataset$Genero)
dataset$Estado_Civil_Label <- as.numeric(dataset$Estado_Civil)

# 3. Comparar cómo los modelos de machine learning reaccionan a diferentes codificaciones
# Dividir dataset en entrenamiento y prueba
set.seed(123)
train_index <- createDataPartition(dataset$Satisfacción, p = .8, 
                                   list = FALSE, 
                                   times = 1)
dataset_train <- dataset[train_index, ]
dataset_test <- dataset[-train_index, ]

# Modelo con One-hot encoding
model_one_hot <- train(Satisfacción ~ ., data = dataset_encoded, method = "lm")

# Modelo con Label encoding
model_label <- train(Satisfacción ~ Genero_Label + Estado_Civil_Label, data = dataset, method = "lm")

# Comparar resultados
predictions_one_hot <- predict(model_one_hot, newdata = dataset_encoded)
predictions_label <- predict(model_label, newdata = dataset)

cat("Predicciones One-hot Encoding:\n")
print(predictions_one_hot)

cat("\nPredicciones Label Encoding:\n")
print(predictions_label)
