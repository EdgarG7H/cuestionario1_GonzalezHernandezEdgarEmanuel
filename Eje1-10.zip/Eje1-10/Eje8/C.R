# 1. Crear datasets de ejemplo
# Crear un dataframe de clientes
set.seed(123)  # Para reproducibilidad
clientes <- data.frame(
  ID_Cliente = 1:100,
  Edad = sample(18:65, 100, replace = TRUE),
  Ingreso_Mensual = sample(5000:100000, 100, replace = TRUE),
  Género = sample(c("M", "F"), 100, replace = TRUE),
  Satisfacción = sample(1:10, 100, replace = TRUE),
  Estado_Civil = sample(c("Soltero", "Casado", "Divorciado"), 100, replace = TRUE)
)

# Crear un dataframe de compras
compras <- data.frame(
  ID_Cliente = sample(1:100, 200, replace = TRUE),  # Clientes pueden comprar múltiples veces
  Fecha_Compra = sample(seq(as.Date('2023-01-01'), as.Date('2023-12-31'), by="day"), 200, replace = TRUE),
  Monto = runif(200, 50, 500)  # Monto de compra aleatorio entre 50 y 500
)

# 1. Cargar los datasets
clientes <- read.csv("clientes.csv")  # Asegúrate de que la ruta sea correcta
compras <- read.csv("historial_compras.csv")  # Asegúrate de que la ruta sea correcta

# 2. Fusionar los datos usando left_join()
library(dplyr)

datos_fusionados <- left_join(compras, clientes, by = "ID_Cliente")

# 3. Detectar y manejar duplicados con distinct()
datos_unicos <- distinct(datos_fusionados)

# 4. Verificar si hay inconsistencias después de la integración
# Ejemplo de verificación: comprobar si hay NA en columnas clave
inconsistencias <- datos_unicos %>%
  filter(is.na(Edad) | is.na(Ingreso_Mensual) | is.na(Género))

# Mostrar resultados
print("Datos fusionados:")
print(head(datos_fusionados))
print("Datos únicos:")
print(head(datos_unicos))
print("Inconsistencias encontradas:")
print(inconsistencias)
