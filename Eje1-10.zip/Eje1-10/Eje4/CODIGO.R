
# Crear el dataset
dataset <- data.frame(
  ID = 1:10,
  Fecha = as.Date(c("2025-03-01", "2025-03-02", "2025-03-03", "2025-03-04", "2025-03-05",
                    "2025-03-06", "2025-03-07", "2025-03-08", "2025-03-09", "2025-03-10")),
  Categoria = c("Publicación", "Historia", "Publicación", "Historia", "Publicación",
                "Historia", "Publicación", "Historia", "Publicación", "Historia"),
  Interacciones = c(150, 200, 300, 250, 400, 100, 500, 350, 450, 600),
  Seguidores = c(1000, 1500, 2000, 1200, 1800, 900, 2500, 1600, 2200, 3000),
  Satisfacción = c(8, 7, 9, 6, 10, 5, 9, 8, 7, 10)
)

# 1. Identificar outliers mediante diagramas de caja
boxplot(dataset$Interacciones, main="Diagrama de Caja - Interacciones")

# 2. Usar el rango intercuartil para determinar límites de outliers
Q1 <- quantile(dataset$Interacciones, 0.25)
Q3 <- quantile(dataset$Interacciones, 0.75)
IQR <- Q3 - Q1

# Límites para outliers
limite_inferior <- Q1 - 1.5 * IQR
limite_superior <- Q3 + 1.5 * IQR

cat("Límite inferior:", limite_inferior, "\n")
cat("Límite superior:", limite_superior, "\n")

# 3. Manejar los valores atípicos mediante eliminación o transformación
# Aquí eliminamos los outliers
dataset_sin_outliers <- dataset[dataset$Interacciones >= limite_inferior & dataset$Interacciones <= limite_superior, ]

# 4. Comparar estadísticas antes y después del tratamiento
cat("Estadísticas antes del tratamiento:\n")
summary(dataset$Interacciones)

cat("\nEstadísticas después del tratamiento:\n")
summary(dataset_sin_outliers$Interacciones)

# Mostrar el dataset sin outliers
print(dataset_sin_outliers)
