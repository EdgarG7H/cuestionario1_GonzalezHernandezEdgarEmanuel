# Cargar librerías necesarias
library(dplyr)

# Supongamos que tenemos un dataframe de ejemplo con respuestas de una encuesta
set.seed(123)
datos <- data.frame(
  satisfaccion = sample(c("baja", "media", "alta"), 100, replace = TRUE),
  edad = sample(18:65, 100, replace = TRUE)
)

# 1. Convertir variables categóricas en factores
datos$satisfaccion <- as.factor(datos$satisfaccion)

# Verificar la conversión
str(datos)

# 2. Aplicar codificación one-hot
datos_one_hot <- model.matrix(~ satisfaccion - 1, data = datos)

# Combinar los datos originales con los datos one-hot
datos_final <- cbind(datos, datos_one_hot)

# 3. Evaluar cómo estas transformaciones impactan en modelos de regresión
# Supongamos que queremos predecir la edad en función de la satisfacción
modelo <- lm(edad ~ satisfaccion, data = datos)
summary(modelo)

# Modelo con datos one-hot
modelo_one_hot <- lm(edad ~ satisfaccionalta + satisfaccionmedia, data = datos_final)
summary(modelo_one_hot)
